import React, { Component } from 'react'
import PayrollContract from '../build/contracts/Payroll.json'
import getWeb3 from './utils/getWeb3'

import { Layout, Menu, Spin, Alert } from 'antd';

// import Accounts from './components/Accounts';
import Employer from './components/Employer';
import Employee from './components/Employee';
// import Common from './components/Common';

// import './css/oswald.css'
// import './css/open-sans.css'
// import './css/pure-min.css'
import 'antd/dist/antd.css';
import './App.css';

const { Header, Content, Footer } = Layout;

class App extends Component {
  constructor(props){
    super(props)

    this.state = {
      storageValue : 0,
      web3: null,
      mode:'employer'
    }
  }

  componentWillMount() {
    getWeb3
    .then(results => {
      this.setState({
        web3: results.web3
      })

      this.instantiateContract()
    })
    .catch(() =>{
      console.log('Error finding web3.')
    })
  }

  instantiateContract(){
    const contract = require('truffle-contract')
    const Payroll = contract(PayrollContract)
    Payroll.setProvider(this.state.web3.currentProvider)

    var PayrollInstance
    // Get accounts
    this.state.web3.eth.getAccounts((error,accounts) => {
      this.setState({
        // accounts,
        // selectedAccount:accounts[0]
        account:accounts[0],
      });
      Payroll.deployed().then((instance) =>{
        PayrollInstance = instance
        this.setState({
          payroll:instance
        });
      })
    })
  }

  onSelectTab = ({key}) => {
    this.setState({
      mode:key
    });
  }

  renderContent = () => {
    const { account, payroll, web3, mode } = this.state;

    if(!payroll) {
      return <Spin tip="Loading.hhhh.." />;
    }

    switch(mode){
      case 'employer':
        return <Employer account={account} payroll={payroll} web3={web3} />
      case 'employee':
        return <Employee account={account} payroll={payroll} web3={web3} />
      default:
        return <Alert message="please select one mode" type="info" showIcon />
    }
  }
  // onSelectAccount = (ev) => {
  //   this.setState({
  //     selectedAccount: ev.target.text
  //   });
  // }

  render(){
    // const { selectedAccount, accounts, payroll, web3 } = this.state;
  
    // if(!accounts) {
    //   return <div>Loading</div>;
    //  }

     return (
       <Layout>
         <Header className="header">
            <div className="logo">Old Dong BlockChain Employee System</div>
          
            <Menu
              theme="dark"
              mode="horizontal"
              defaultSelectedKeys={['employer']}
              style={{ lineHeight: '64px' }}
              onSelect={this.onSelectTab}
            >
                <Menu.Item key="employer">Employer</Menu.Item>
                <Menu.Item key="employee">Employee</Menu.Item>
            </Menu>
          </Header>
          <Content style={{padding:'0 50px'}}>
            <Layout style={{ padding: '24px 0', background: '#fff', minHeight: '600px' }}>
                {this.renderContent()}  
            </Layout>
          </Content>
          <Footer style={{textAlign: 'center' }}>
            Payroll ©2018 BlockChain
          </Footer>
       </Layout>
      //  <div className="App">
      //     <nav className="navbar pure-menu pure-menu-horizontal">
      //          <a href="#" className="pure-menu-heading pure-menu-link">Payroll</a>  
      //     </nav>
      //     <main className="container">
      //        <div className="pure-g">
      //            <div className="pure-u-1-3">
      //               <Accounts accounts={accounts} onSelectAccount={this.onSelectAccount}/>
      //             </div>
      //           <div className="pure-u-2-3">
      //             {
      //               selectedAccount === accounts[0] ?
      //               <Employer employer={selectedAccount} payroll={payroll} web3={web3}/>:
      //               <Employee employee={selectedAccount} payroll={payroll} web3={web3}/>
      //             }
      //             {payroll && <Common account={selectedAccount} payroll={payroll} web3={web3}/> }
      //           </div>
      //         </div>
      //    </main>
         
      //  </div>
     );
  }
}
export default App