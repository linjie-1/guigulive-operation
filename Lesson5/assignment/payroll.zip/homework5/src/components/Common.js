import React, { Component } from 'react'
import { Card, Col, Row } from 'antd';

class Common extends Component {
    constructor(props){
        super(props);
        this.state = {};
    }
    
    componentDidMount() {
        // const { payroll, web3 } = this.props;
        // const updateInfo = (error, result) => {
        //   if (!error) {
        //     this.checkInfo();
        //   }
        // }
    
        // this.newFund = payroll.addFund(updateInfo);
        // this.getPaid = payroll.getPaid(updateInfo);
        // this.newEmployee = payroll.addEmployee(updateInfo);
        // this.updateEmployee = payroll.updateEmployee(updateInfo);
        // this.removeEmployee = payroll.removeEmployee(updateInfo);
    
        this.checkInfo();
      }
    
    //   componentWillUnmount() {
    //     this.newFund.stopWatching();
    //     this.getPaid.stopWatching();
    //     this.newEmployee.stopWatching();
    //     this.updateEmployee.stopWatching();
    //     this.removeEmployee.stopWatching();
    //   }
    
      checkInfo = () => {
        const { payroll, account, web3 } = this.props;
        payroll.checkInfo.call({
          from: account,
        }).then((result) => {
          this.setState({
            balance: web3.fromWei(result[0].toNumber()),
            runway: result[1].toNumber(),
            employeeCount: result[2].toNumber()
          })
        });
      }
    

    render(){
        const { runway, balance, employeeCount } = this.state;
        return (
            <div>
                <h2>Common Info</h2>
                {/* <p>contract amount:{balance}</p>
                <p>employee count: {emploeeCount}</p>
                <p>pay num:{runway}</p> */}
                <Row gutter={16}>
                    <Col span={8}>
                        <Card title="contract amount">{balance} Ether</Card>
                    </Col>
                    <Col span={8}>
                        <Card title="employee count">{employeeCount}</Card>
                    </Col>
                    <Col span={8}>
                        <Card title="Pay Times">{runway}</Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Common