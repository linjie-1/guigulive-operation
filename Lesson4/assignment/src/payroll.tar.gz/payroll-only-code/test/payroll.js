var Payroll = artifacts.require("./Payroll.sol");

contract("Payroll-removeEmployee", function(accounts) {
     var removeAddress = 0x1238420F4922DB63eA2392194760348ED4Fe4DEF;
     it("...Remove Employee removeAddress success.", function() {
         return Payroll.deployed().then(function(instance) {
             payrollInstance = instance;
             return payrollInstance.addEmployee(removeAddress,1);
        }).then(function() {
             return payrollInstance.removeEmployee(removeAddress);
         }).then(function() {
             return payrollInstance.employeeIsExist.call(removeAddress);
         }).then(function(isExist) {
             assert.equal(isExist, false, "Remove Employee removeAddress success.");
         });
     });
     
});


contract("Payroll-addEmployee", function(accounts) {
    var newAddress = 0x1238420F4922DB63eA2392194760348ED4Fe4ABC;
        it("...Add Employee newAddress success.", function() {
            return Payroll.deployed().then(function(instance) {
                payrollInstance = instance;
                return payrollInstance.addEmployee(newAddress,1,{from: accounts[0]});
            }).then(function() {
                return payrollInstance.employeeIsExist.call(newAddress);
            }).then(function(isExist) {
                assert.equal(isExist, true, "Add Employee newAddress success.");
            });
    });
});


contract("Payroll-addEmployee-catchError", function(accounts) {
    var newAddress = 0x1238420F4922DB63eA2392194760348ED4Fe4ABC;
        it("...Add Employee newAddress success.", function() {
            return Payroll.deployed().then(function(instance) {
                payrollInstance = instance;
                return payrollInstance.addEmployee(newAddress,1,{from: accounts[0]});
            }).then(function() {
                return payrollInstance.addEmployee(newAddress,2,{from: accounts[0]});
            }).catch(function(error) {
                console.log(error.toString());
                assert(error.toString().includes('invalid'), "addEmployee");
                
            });
    });
});


contract("Payroll-removeEmployee-catchError", function(accounts) {
    var removeAddress = 0x1238420F4922DB63eA2392194760348ED4Fe4DEF;
    it("...Remove Employee removeAddress success.", function() {
        return Payroll.deployed().then(function(instance) {
            return payrollInstance.removeEmployee(removeAddress);
        }).catch(function(error) {
            console.log(error.toString());
            assert(error.toString().includes('invalid'), "removeEmployee");
        });
    });
});

contract("Payroll-getPaid-MsgSender", function(accounts) {
    it("...getPaid success.", function() {
        return Payroll.deployed().then(function(instance) {
            payrollInstance = instance;
            return payrollInstance.addEmployee(accounts[0],1);
        }).then(function() {
            setTimeout(function(){
                return payrollInstance.getPaid();
            },11000);   
            }).then(function(getsalary) {
                console.log(getsalary);
                assert.equal(getsalary > 0, true, "getPaid success.");
              });
    });
});

contract("Payroll-getPaid-notMsgSender", function(accounts) {
    it("...getPaid success.", function() {
        return Payroll.deployed().then(function(instance) {
            payrollInstance = instance;
            return payrollInstance.addEmployee(accounts[1],1);
        }).then(function() {
            setTimeout(function(){
                return payrollInstance.getPaid();
            },11000);   
            }).then(function(getsalary) {
                assert.equal(getsalary > 0, true, "getPaid success.");
              });
    });
});