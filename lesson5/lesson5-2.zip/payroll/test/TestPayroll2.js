var Payroll=artifacts.require("./Payroll.sol")

contract("Payroll",function(accounts){

    it("add an employee.",function(){
        console.log("add an employee.");
        //var payrollInstance;
        return Payroll.deployed().then(function(instance){
            payrollInstance=instance;
            return payrollInstance.addEmployee(accounts[1],1);
        }).then(function(){
            assert(true,"The employee was added.");
        });
    })

    it("add an employee.",function(){
        console.log("add an employee.");
        return Payroll.deployed().then(function(instance){
            payrollInstance=instance;
            return payrollInstance.addEmployee(accounts[0],1);
        }).then(function(){
            assert(true,"The employee was added.");
        });
    })

    it(" Can't add a duplicate employee.",function(){
        console.log("add an duplicate employee.");
        var payrollInstance;
        return Payroll.deployed().then(function(instance){
            payrollInstance=instance;
            return payrollInstance.addEmployee(accounts[1],1);
        }).catch(function(error){
            assert(error.toString().includes('invalid opcode'),"The employee was added.");
        });
    })

    it("delete an employee.",function(){
        console.log("delet an employee.");
        return Payroll.deployed().then(function(instance){
            payrollInstance=instance;
            return payrollInstance.removeEmployee(accounts[0])
        }).then(function(){
            assert(true,"The employee was delete.");
        });
    })

    it("Can't delete not existed employee.", function() {
        console.log("Can't delete not existed employee.");
        return Payroll.deployed().then(function(instance) {
            payrollInstance = instance;
            return payrollInstance.removeEmployee(accounts[8]);
        }).catch(function(error) {
            assert(error.toString().includes('invalid opcode'), "Try again!");
        });
    })

});