import React, { Component } from 'react'
import PayrollContract from '../build/contracts/Payroll.json'
import getWeb3 from './utils/getWeb3'

import { Layout, Menu, Spin, Alert } from 'antd';

// import Accounts from './components/Accounts';
import Employer from './components/Employer';
import Employee from './components/Employee';
// import Common from './components/Common';

// import './css/oswald.css'
// import './css/open-sans.css'
// import './css/pure-min.css'
import 'antd/dist/antd.css';
import './App.css';

const { Header, Content, Footer } = Layout;

class App extends Component {
  constructor(props){
    super(props)

    this.state = {
      storageValue : 0,
      web3: null,
      mode:'employer'
    }
  }

  componentWillMount() {

    //Get network provider and web3 instance 
    //See utils/getWeb3 for more info
    getWeb3
    .then(results => {
      this.setState({
        web3: results.web3
      })
      //Instaniate contract onece web3 provided
      this.instantiateContract()
    })
    .catch(() =>{
      console.log('Error finding web3.')
    })
  }

  instantiateContract(){
    const contract = require('truffle-contract')
    const Payroll = contract(PayrollContract)
    Payroll.setProvider(this.state.web3.currentProvider)

    var PayrollInstance
    // Get accounts
    this.state.web3.eth.getAccounts((error,accounts) => {
      this.setState({
        // accounts,
        // selectedAccount:accounts[0]
        account:accounts[0],
      });
      Payroll.deployed().then((instance) =>{
        PayrollInstance = instance
        this.setState({
          payroll:instance
        });
      })
    })
  }

  onSelectTab = ({key}) => {
    this.setState({
      mode:key
    });
  }

  renderContent = () => {
    const { account, payroll, web3, mode } = this.state;

    if(!payroll) {
      return <Spin tip="Loading..." />;
    }

    switch(mode){
      case 'employer':
        return <Employer account={account} payroll={payroll} web3={web3} />
      case 'employee':
        return <Employee account={account} payroll={payroll} web3={web3} />
      default:
        return <Alert message="please select one mode" type="info" showIcon />
    }
  }


  render(){
    return (
       <Layout>
         <Header className="header">
            <div className="logo">Old Dong BlockChain Employee System</div>
            <Menu
              theme="dark"
              mode="horizontal"
              defaultSelectedKeys={['employer']}
              style={{ lineHeight: '64px' }}
              onSelect={this.onSelectTab}
            >
                <Menu.Item key="employer">Employer</Menu.Item>
                <Menu.Item key="employee">Employee</Menu.Item>
            </Menu>
          </Header>
          <Content style={{padding:'0 50px'}}>
            <Layout style={{ padding: '24px 0', background: '#fff', minHeight: '600px' }}>
                {this.renderContent()}  
            </Layout>
          </Content>
          <Footer style={{textAlign: 'center' }}>
            Payroll ©2018 BlockChain
          </Footer>
       </Layout>
      //  <div className="App">
      //     <nav className="navbar pure-menu pure-menu-horizontal">
      //          <a href="#" className="pure-menu-heading pure-menu-link">Payroll</a>  
      //     </nav>
      //     <main className="container">
      //        <div className="pure-g">
      //            <div className="pure-u-1-3">
      //               <Accounts accounts={accounts} onSelectAccount={this.onSelectAccount}/>
      //             </div>
      //           <div className="pure-u-2-3">
      //             {
      //               selectedAccount === accounts[0] ?
      //               <Employer employer={selectedAccount} payroll={payroll} web3={web3}/>:
      //               <Employee employee={selectedAccount} payroll={payroll} web3={web3}/>
      //             }
      //             {payroll && <Common account={selectedAccount} payroll={payroll} web3={web3}/> }
      //           </div>
      //         </div>
      //    </main>
         
      //  </div>
     );
  }
}
export default App







// Available Accounts
// ==================
// (0) 0x2e6621ef6fa89d8c7474703678bd5319df1ff1d8
// (1) 0x3efb14cf545d1e2d53c1e05434e107eb5a0b18bb
// (2) 0x6130615575e01165c89e8050234c627498463125
// (3) 0x773ef191cf8edd389e7be5517537a6dd170e1e2f
// (4) 0x9cae6a7cf8753194dc3799e7d91173c5234a643f
// (5) 0x46420f7a2cb309397076c4991cfa93870aa82b68
// (6) 0x62cefb4d9ba4aff3562732c70bc24888f89729c6
// (7) 0xaae93ad136071ec61096c8f882c0d8e59b393767
// (8) 0x166dc58d99aeaa51934e5ceb6191bad51cfe8216
// (9) 0x39f2a2a249a5ec7acd6ef0684c029cec3602d56a

// Private Keys
// ==================
// (0) e263a56f78fd273a2eae9f1ff52ccad37b2c04623736b7e43616b6f5cfe28acf
// (1) 0e8c181f04756e3d298e9d60ed9df49089472b1b58c650b8f9867d20bde7b8cb
// (2) 3d53f2976c85dda5ff52996fef3c9473a5fb5f3845fa5a4f0f62387c213d2ee3
// (3) 898abc20e69a46c7ac0e4e23e5393690a04b745d7b5bad8dbab78a801d8ea22f
// (4) bc5d476299ef08e7c001cc985e67c2b3a61d5cf60f5508d0d705864a5b19387b
// (5) 3a05eb3f69b2c8411713cb3042b598cb6bbc6460525bd8eaf94bce4b2f02e33c
// (6) 3070f104cd4e83386c5e538d812653e14509ec864899eed7e4d075ee70907919
// (7) 745becb2f23c67a604b1119111fe332672f9795189076a48413052a2233891b0
// (8) 70fe21bf47f06c2cfcf0a3619c36b45d4e52f8443ebd641fff9985db1f9e043a
// (9) 03e9a3a1281edd3437f6a514df6897956f21e220236999fabf17059dda7405ab

// HD Wallet
// ==================
// Mnemonic:      afford gentle blood pass slide diesel work fox oppose spatial tone song
// Base HD Path:  m/44'/60'/0'/0/{account_index}

// Listening on localhost:8545
